package com.elkin.pruebaTecnica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaTecnicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
