package com.elkin.pruebaTecnica.persistence.entity;

public enum TipoMovimientoEnum {
    DEBITO,
    CREDITO
}
