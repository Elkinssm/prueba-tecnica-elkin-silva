package com.elkin.pruebaTecnica.persistence.entity;

public enum GeneroEnum {
    MASCULINO,
    FEMENINO,
    OTRO
}
