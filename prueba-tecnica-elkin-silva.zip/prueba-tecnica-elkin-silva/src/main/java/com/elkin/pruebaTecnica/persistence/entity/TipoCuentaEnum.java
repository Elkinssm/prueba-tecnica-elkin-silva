package com.elkin.pruebaTecnica.persistence.entity;

public enum TipoCuentaEnum {
    Ahorros, Corriente
}
