package com.elkin.pruebaTecnica.service.dto;

import com.elkin.pruebaTecnica.persistence.entity.Cuenta;
import com.elkin.pruebaTecnica.persistence.entity.Movimiento;
import com.elkin.pruebaTecnica.persistence.entity.TipoMovimientoEnum;
import com.elkin.pruebaTecnica.persistence.repository.CuentaRepository;
import com.elkin.pruebaTecnica.persistence.repository.MovimientoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class MovimientoService {

    private final MovimientoRepository movimientoRepository;
    private final CuentaRepository cuentaRepository;

    public MovimientoService(MovimientoRepository movimientoRepository, CuentaRepository cuentaRepository) {
        this.movimientoRepository = movimientoRepository;
        this.cuentaRepository = cuentaRepository;
    }

    public Movimiento crearMovimiento(Long idCuenta, TipoMovimientoEnum tipoMovimiento, Double valor) throws Exception {
        Optional<Cuenta> cuentaOptional = cuentaRepository.findById(idCuenta);
        if (!cuentaOptional.isPresent()) {
            throw new Exception("La cuenta con id " + idCuenta + " no existe");
        }

        Cuenta cuenta = cuentaOptional.get();
        if (!cuenta.getEstado()) {
            throw new Exception("La cuenta con id " + idCuenta + " se encuentra inactiva");
        }

        Double saldoActual = cuenta.getSaldoInicial();
        Double nuevoSaldo = tipoMovimiento == TipoMovimientoEnum.RETIRO ? saldoActual - valor : saldoActual + valor;

        if (nuevoSaldo < 0) {
            throw new Exception("La cuenta con id " + idCuenta + " no tiene saldo suficiente para realizar la transacción");
        }

        Movimiento movimiento = new Movimiento();
        movimiento.setCuenta(cuenta);
        movimiento.setTipoMovimiento(tipoMovimiento);
        movimiento.setValor(valor);
        movimiento.setSaldoAnterior(saldoActual);
        movimiento.setSaldoActual(nuevoSaldo);

        cuenta.setSaldoInicial(nuevoSaldo);
        cuentaRepository.save(cuenta);
        return movimientoRepository.save(movimiento);
    }
}
