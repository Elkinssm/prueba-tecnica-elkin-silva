package com.elkin.pruebaTecnica.persistence.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

public enum TransaccionEnum {
    DEBITO, CREDITO
}