# Prueba Tecnica - Neoris
## Summary
En este repositorio se puede encontrar el código correspondiente a una API rest, como desarrollo de una prueba tecnica de java


Para ver la interfaz web donde se muestran todos los puntos finales de la API con los datos que reciben y cómo los utilizan, se utilizó https://swagger.io/, alojado en localhost usando una base de datos relacional PostgresSQL.

[![Capture.png](https://i.postimg.cc/9f36v0Nk/Capture.png)](https://postimg.cc/4Y52cfGv)
[![Screenshot-2023-02-15-213542.jpg](https://i.postimg.cc/FKk15WFF/Screenshot-2023-02-15-213542.jpg)](https://postimg.cc/cKZdfc8P)
